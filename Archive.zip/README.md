<div align="center">
<h2>
 An (extremely) short game for a school reasearch project.
</h2>
</div>
</br>


<i>
  Needs: Python 3.11 and Pygame, or you could download the .ZIP</br>
</i>
<br/>

<p>
<div align="center">Installation Instructions:</div><hr>
For simple installation, just download and extract the .ZIP file. Please keep in mind that all the extracted files from that folder must be put in the same folder as each other. After that, just run the .exe and you're good to go!
Your antivirus will likely flag this as a suspicious program, but that can be ignored. Just because the program isn't from a verified source just means that I am not going to go through the effort of doing that for a school project. All the source code is open to view, if you want to ensure that there is no malware. 
</p>

<h6>"If you have any more questions / bug reports, feel free to reach me from whatever source I sent this game to you. Enjoy playing!"</h6>
